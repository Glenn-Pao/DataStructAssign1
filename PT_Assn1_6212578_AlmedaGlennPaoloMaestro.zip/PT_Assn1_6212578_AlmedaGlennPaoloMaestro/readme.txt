To compile the program, please enter the following
g++ Application.cpp LocationData.cpp LocationData.h MissionPlan.cpp MissionPlan.h NewEntryInput.cpp NewEntryInput.h PointTwoD.cpp PointTwoD.h -o PT_Assn1_6212578_AlmedaGlennPaoloMaestro.exe 2>error.txt

To run the program, please enter this after compiling the program
./PT_Assn1_6212578_AlmedaGlennPaoloMaestro.exe

Note: The error.txt is used for debugging. If it is empty, there are no errors encountered and should be able to run the PT_Assn1_6212578_AlmedaGlennPaoloMaestro.exe file
